import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User as FirebaseUser,
  onAuthStateChanged,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendEmailVerification,
  sendPasswordResetEmail,
  signOut as firebaseSignOut,
  updateProfile,
} from 'firebase/auth';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db, googleProvider } from '../firebase/config';
import { UserProfile } from '../types';
import { handleFirestoreError, OperationType } from '../firebase/error';

interface AuthContextType {
  currentUser: FirebaseUser | null;
  userProfile: UserProfile | null;
  loading: boolean;
  isAdmin: boolean;
  signInWithGoogle: () => Promise<void>;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  signupWithEmail: (
    email: string,
    pass: string,
    fullName: string,
    role: 'builder' | 'owner',
    institution?: string,
    department?: string
  ) => Promise<void>;
  sendVerificationEmail: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  updateProfileData: (data: Partial<UserProfile>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  // Helper to fetch or create user profile doc in Firestore
  const fetchOrCreateProfile = async (fbUser: FirebaseUser, defaultRole: 'builder' | 'owner' = 'builder', additionalData?: Partial<UserProfile>) => {
    try {
      const userRef = doc(db, 'users', fbUser.uid);
      const snap = await getDoc(userRef);

      const isDefaultAdmin = fbUser.email === 'enbarajenba21@gmail.com';

      if (snap.exists()) {
        const data = snap.data() as UserProfile;
        // Check if admin override applies
        if (isDefaultAdmin && data.role !== 'admin') {
          const updated: UserProfile = { ...data, role: 'admin', accountType: 'Platform Administrator' };
          await setDoc(userRef, updated, { merge: true });
          setUserProfile(updated);
          return updated;
        }
        setUserProfile(data);
        return data;
      } else {
        // Construct fresh profile
        const newProfile: UserProfile = {
          id: fbUser.uid,
          fullName: fbUser.displayName || additionalData?.fullName || (fbUser.email ? fbUser.email.split('@')[0] : 'User'),
          email: fbUser.email || '',
          phone: additionalData?.phone || '',
          role: isDefaultAdmin ? 'admin' : (additionalData?.role || defaultRole),
          accountType: isDefaultAdmin
            ? 'Platform Administrator'
            : (additionalData?.role === 'owner' ? 'Problem Owner / Organization' : 'Student Builder / Innovator'),
          institution: additionalData?.institution || 'Academic / Partner Org',
          department: additionalData?.department || 'Engineering',
          degree: additionalData?.degree || 'B.Tech / Professional',
          rollNo: additionalData?.rollNo || 'PB-' + fbUser.uid.substring(0, 6).toUpperCase(),
          city: additionalData?.city || 'Bengaluru',
          state: additionalData?.state || 'Karnataka',
          bio: additionalData?.bio || 'Problem solver passionate about creating real-world societal impact through technology.',
          skills: additionalData?.skills || ['Problem Solving', 'React', 'TypeScript', 'Node.js'],
          githubUrl: additionalData?.githubUrl || '',
          linkedinUrl: additionalData?.linkedinUrl || '',
          avatarUrl: fbUser.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${fbUser.uid}`,
          registrationDate: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
          registrationStatus: 'Verified',
          idVerificationType: 'Official Institutional Email',
          idCardVerified: true,
          canPostProblems: isDefaultAdmin || additionalData?.role === 'owner',
          isLoggedIn: true,
        };

        await setDoc(userRef, {
          ...newProfile,
          createdAt: new Date().toISOString(),
          serverTimestamp: serverTimestamp(),
        });
        setUserProfile(newProfile);
        return newProfile;
      }
    } catch (err) {
      console.error('Error fetching or creating profile:', err);
      handleFirestoreError(err, OperationType.WRITE, `users/${fbUser.uid}`);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        await fetchOrCreateProfile(user);
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    try {
      const res = await signInWithPopup(auth, googleProvider);
      if (res.user) {
        await fetchOrCreateProfile(res.user);
      }
    } catch (err: any) {
      console.error('Google Sign-In Error:', err);
      throw err;
    }
  };

  const loginWithEmail = async (email: string, pass: string) => {
    try {
      const res = await signInWithEmailAndPassword(auth, email, pass);
      if (res.user) {
        await fetchOrCreateProfile(res.user);
      }
    } catch (err: any) {
      console.error('Email Login Error:', err);
      throw err;
    }
  };

  const signupWithEmail = async (
    email: string,
    pass: string,
    fullName: string,
    role: 'builder' | 'owner',
    institution?: string,
    department?: string
  ) => {
    try {
      const res = await createUserWithEmailAndPassword(auth, email, pass);
      if (res.user) {
        await updateProfile(res.user, { displayName: fullName });
        await fetchOrCreateProfile(res.user, role, {
          fullName,
          role,
          institution: institution || 'Academic Institution',
          department: department || 'Engineering & Technology',
        });
        // Send email verification
        try {
          await sendEmailVerification(res.user);
        } catch (e) {
          console.warn('Could not send verification email immediately', e);
        }
      }
    } catch (err: any) {
      console.error('Signup Error:', err);
      throw err;
    }
  };

  const sendVerificationEmail = async () => {
    if (auth.currentUser) {
      await sendEmailVerification(auth.currentUser);
    }
  };

  const resetPassword = async (email: string) => {
    await sendPasswordResetEmail(auth, email);
  };

  const logout = async () => {
    await firebaseSignOut(auth);
    setUserProfile(null);
  };

  const refreshProfile = async () => {
    if (currentUser) {
      await fetchOrCreateProfile(currentUser);
    }
  };

  const updateProfileData = async (data: Partial<UserProfile>) => {
    if (!currentUser) throw new Error('Not authenticated');
    const userRef = doc(db, 'users', currentUser.uid);
    try {
      await setDoc(userRef, data, { merge: true });
      setUserProfile((prev) => (prev ? { ...prev, ...data } : null));
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${currentUser.uid}`);
    }
  };

  const isAdmin = userProfile?.role === 'admin' || currentUser?.email === 'enbarajenba21@gmail.com';

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        loading,
        isAdmin,
        signInWithGoogle,
        loginWithEmail,
        signupWithEmail,
        sendVerificationEmail,
        resetPassword,
        logout,
        refreshProfile,
        updateProfileData,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
